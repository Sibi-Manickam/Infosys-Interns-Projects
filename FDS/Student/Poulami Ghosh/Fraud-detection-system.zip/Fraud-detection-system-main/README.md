# Fraud-detection-system
Built a machine learning model using various processes like data cleaning , feature engineering , and algorithms to predict whether a transaction done is Fraud or not.
